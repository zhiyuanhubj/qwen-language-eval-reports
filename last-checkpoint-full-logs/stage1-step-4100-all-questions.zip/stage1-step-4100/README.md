# STAGE1 最后checkpoint：4100 完整题目日志

正式回答：984/984。与原回答SHA匹配的评分：984/984。

三个subset：diagnostic128 / benchmark72 / friend46。四组设置：Thinking、NoTags，各含T0.6/p0.95与T1/p1。

- readable/：四个UTF-8文本，每个文件包含全部246题的提示、完整thinking、最终答案和可用逐项评分。
- raw/：原始JSONL、运行日志、元数据、标准答案判分与审计文件，保留原有成功、失败、重试和smoke记录。
- questions/：固定246题、参考答案、manifest及全部配图。配图已逐文件校验manifest SHA。
- coverage.json：每组覆盖数及缺失评分ID。
- CHECKSUMS.json：本包各文件的SHA-256。

所有源文件取自此前已上传的GitHub快照，不重新生成模型回答，不修改旧评分。
源commit：a1fed35f881322bf43a1d1af0e651a1c3910bac3
