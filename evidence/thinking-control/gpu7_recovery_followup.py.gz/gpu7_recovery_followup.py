"""Reuse released no-tags eval GPUs for HF Thinking items, without restarting jobs."""
import concurrent.futures
import json
import queue
import subprocess
import time
from pathlib import Path

C = Path(__file__).resolve().parent
R = C.parent
OUT = R / 'evaluation-thinking-246-v1'
E = '/fsx/home/zhiyuan/miniconda3/envs/megatron-sft/bin/python'
UNIT = 'language-pilot-thinking-2800-local-recovery-single-20261014'


def sr():
    return ['srun', '--jobid=2742', '--overlap', '-N1', '-n1', '-c8', '--immediate=30']


def main():
    # Require the original controller to finish and its worker processes to exit.
    while True:
        state = subprocess.check_output(
            ['systemctl', '--user', 'show', UNIT, '-p', 'ActiveState', '-p', 'MainPID'], text=True)
        if 'MainPID=0' in state and ('ActiveState=inactive' in state or 'ActiveState=failed' in state):
            break
        time.sleep(30)
    assert 'fcntl.flock(model_lock.fileno(),' in (C / 'worker.py').read_text()
    items = queue.Queue()
    # HF items need no parent-side staging; all download/cleanup is under the model lock.
    for item in reversed(json.loads((C / 'queue.json').read_text())['items']):
        if not item.get('repo') or (OUT / 'status' / (item['label'] + '.completed.json')).exists():
            continue
        status = OUT / 'status' / (item['label'] + '.json')
        if status.exists() and json.loads(status.read_text()).get('state') not in ('failed', 'completed'):
            continue  # Includes pre-lock workers that were already running when code was deployed.
        items.put(item)
    folder = C / 'gpu7-recovery-items'
    folder.mkdir(exist_ok=True)

    def worker(gpu):
        while True:
            try:
                item = items.get_nowait()
            except queue.Empty:
                return
            try:
                # Never stop another process to obtain a GPU.
                check = subprocess.check_output(sr() + ['nvidia-smi', '-i', str(gpu),
                    '--query-gpu=memory.used', '--format=csv,noheader,nounits'],
                    stdin=subprocess.DEVNULL, text=True)
                if int(check.strip().splitlines()[-1]) >= 1000:
                    raise RuntimeError(f'GPU {gpu} remains occupied; refusing launch')
                path = folder / (item['label'] + '.json')
                path.write_text(json.dumps(item))
                with (OUT / (item['label'] + '.gpu7-recovery-client.log')).open('a') as log:
                    subprocess.run(sr() + [E, str(C / 'worker.py'), str(path), str(gpu)],
                        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, check=True)
            except Exception as exc:
                print('RECOVERY_ITEM_FAILED',item['label'],repr(exc),flush=True)
            finally:
                items.task_done()

    with concurrent.futures.ThreadPoolExecutor(6) as pool:
        list(pool.map(worker, [7]))
    (C / 'gpu7-recovery-finished.json').write_text(json.dumps({'utc': time.time()}))


if __name__ == '__main__':
    main()
