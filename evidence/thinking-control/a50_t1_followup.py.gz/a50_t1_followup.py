from pathlib import Path
import subprocess,json,time,fcntl
C=Path(__file__).resolve().parent;R=C.parent;OUT=R/'evaluation-thinking-246-v1';E='/fsx/home/zhiyuan/miniconda3/envs/megatron-sft/bin/python'
lock=(C/'a50-t1-followup.lock').open('a');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
while True:
 p=subprocess.run(['systemctl','--user','show','language-pilot-thinking-eval-20261014','--property=ActiveState,MainPID','--no-pager'],stdin=subprocess.DEVNULL,capture_output=True,text=True,check=True)
 fields=dict(x.split('=',1) for x in p.stdout.splitlines() if '=' in x)
 if fields.get('ActiveState')=='inactive' and fields.get('MainPID')=='0' and (C/'controller-finished.json').exists():break
 (C/'a50-t1-followup-waiting.json').write_text(json.dumps({'utc':time.time(),'waiting':'original GPU0/1 controller terminal before exclusive GPU0 use','observed':fields}));time.sleep(30)
sr=['srun','--jobid=2742','--overlap','-N1','-n1','-c1','--immediate=30']
p=subprocess.run(sr+['nvidia-smi','--id=0','--query-gpu=memory.used','--format=csv,noheader,nounits'],stdin=subprocess.DEVNULL,capture_output=True,text=True,check=True)
assert int(p.stdout.strip())<1000,p.stdout
with (OUT/'prior-A50.t1-followup.client.log').open('a') as log:
 q=subprocess.run(sr+[E,str(C/'worker_a50_t1_followup.py'),str(C/'items/prior-A50.json'),'0'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
assert q.returncode==0,q.returncode
