import subprocess,json,time
from pathlib import Path
R=Path('/fsx/home/zhiyuan/language-pilot-20261011')
def sr(j):return ['srun','--jobid='+str(j),'--overlap','-N1','-n1','-c4','--immediate=30']
used=subprocess.check_output(sr(2812)+['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True)
assert max(map(int,used.split()))<1000
raw=subprocess.check_output(sr(2546)+['docker','inspect','llava-v41-quality-native-dp2'],text=True)
x=json.loads(raw)[0];args=x['Config']['Cmd'][:]
for flag,value in [('--max-model-len','131072'),('--max-num-seqs','32'),('--port','30241')]:args[args.index(flag)+1]=value
cmd=['docker','run','--rm','--name','qwen-eval-long-judge-20261014','--gpus','all','--network','host','--ipc','host']
cmd+=['-v','/fsx/data/zhiyuan/models/DeepSeek-V4.1-Flash:/model:ro','-v','/opt/dlami/nvme/zhiyuan:/nvme','-v','/etc/ssl/certs/ca-certificates.crt:/run/ca-certificates.crt:ro']
# Preserve only non-secret runtime switches needed by the existing server.
for env in x['Config']['Env']:
 key=env.split('=',1)[0]
 if key.startswith(('VLLM_','NCCL_','CUDA_','OMP_','TORCH_','SAFETENSORS_','HF_HUB_')) and not any(s in key for s in ['TOKEN','SECRET','KEY']):cmd+=['-e',env]
cmd += [x['Config']['Image']] + args
result=subprocess.run(sr(2812)+cmd)
raise SystemExit(result.returncode)
