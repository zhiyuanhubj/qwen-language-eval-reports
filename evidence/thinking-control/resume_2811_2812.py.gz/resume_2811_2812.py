"""Resume original evaluation on idle allocations, without altering protocol/results."""
import concurrent.futures
import json
import queue
import subprocess
import time
from pathlib import Path

C = Path(__file__).resolve().parent
R = C.parent
OUT = R / 'evaluation-thinking-246-v1'
E = '/fsx/home/zhiyuan/miniconda3/envs/megatron-sft/bin/python'
N = '/opt/dlami/nvme/zhiyuan/language-pilot-20261011/thinking-eval-20261014'
RUN = C / 'resume-20261014-1500'
RUN.mkdir(exist_ok=True)

def sr(job, cpus=8):
    return ['srun', '--jobid='+str(job), '--overlap', '-N1', '-n1', '-c'+str(cpus), '--immediate=30']

def missing(item):
    total = 0
    for mode in item['modes']:
        p = OUT / mode / (item['label']+'.jsonl')
        ids = set()
        if p.exists():
            with p.open() as f:
                for line in f:
                    row = json.loads(line)
                    if row.get('status') == 'ok':
                        ids.add(row['id'])
        total += 246-len(ids)
    return total

def main():
    work = queue.Queue()
    items = json.loads((C/'queue.json').read_text())['items']
    pending = [(missing(x), x) for x in items]
    pending = [(n, x) for n, x in pending if n and x.get('repo')]
    # Fill largely missing checkpoints first; known context failures are retained.
    for _, item in sorted(pending, key=lambda p: -p[0]):
        work.put(item)
    (RUN/'authorization.json').write_text(json.dumps({
        'user_requested_resume': True, 'jobs': [2811,2812],
        'unchanged_protocol': True, 'utc':time.time(),
        'hf_models':len(pending), 'missing_answers':sum(n for n,_ in pending)}))

    def lane(job, gpu):
        if job == 2812:
            while True:
                status = subprocess.check_output(['systemctl','--user','show',
                    'language-pilot-image-2812-20261014','-p','ActiveState','-p','ExecMainStatus'],text=True)
                if 'ActiveState=failed' in status:
                    raise RuntimeError('Image staging failed')
                if 'ActiveState=active' not in status and 'ActiveState=activating' not in status:
                    break
                time.sleep(15)
        subprocess.run(sr(job,1)+['docker','image','inspect',
            'vllm/vllm-openai:zhiyuan-v41-7d0b4e57a'],stdout=subprocess.DEVNULL,check=True)
        while True:
            try:
                item = work.get_nowait()
            except queue.Empty:
                return
            try:
                used = subprocess.check_output(sr(job,1)+['nvidia-smi','-i',str(gpu),
                    '--query-gpu=memory.used','--format=csv,noheader,nounits'], text=True)
                assert int(used.strip()) < 1000, 'GPU occupied; no process was stopped'
                path = RUN/(item['label']+'.json')
                path.write_text(json.dumps(item))
                with (RUN/(item['label']+'.log')).open('a') as log:
                    result = subprocess.run(sr(job)+[E,str(C/'worker.py'),str(path),str(gpu)],
                        stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
                (RUN/(item['label']+'.exit.json')).write_text(json.dumps({
                    'job':job,'gpu':gpu,'returncode':result.returncode,'utc':time.time()}))
            except Exception as exc:
                print(job,gpu,item['label'],repr(exc),flush=True)
            finally:
                work.task_done()
    with concurrent.futures.ThreadPoolExecutor(16) as pool:
        list(pool.map(lambda p:lane(*p),[(j,g) for j in (2811,2812) for g in range(8)]))
    (RUN/'finished.json').write_text(json.dumps({'utc':time.time()}))

if __name__ == '__main__':
    main()
