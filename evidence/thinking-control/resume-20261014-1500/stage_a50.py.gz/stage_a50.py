import subprocess,json,time
from pathlib import Path
C=Path('/fsx/home/zhiyuan/language-pilot-20261011/thinking-eval-20261014');D=C/'resume-20261014-1500'
item=json.loads((D/'prior-A50.json').read_text())
N='/opt/dlami/nvme/zhiyuan/language-pilot-20261011/thinking-eval-20261014/temporary-models/prior-A50/model'
def sr(j):return ['srun','--jobid='+str(j),'--overlap','-N1','-n1','-c2','--immediate=30']
subprocess.run(sr(2812)+['mkdir','-p',N],check=True)
a=subprocess.Popen(sr(2548)+['tar','-C',item['source_path'],'-cf','-']+[x['file'] for x in item['files']],stdout=subprocess.PIPE)
b=subprocess.Popen(sr(2812)+['tar','-C',N,'-xf','-'],stdin=a.stdout);a.stdout.close()
br=b.wait();ar=a.wait();assert ar==br==0
(D/'a50-staged.json').write_text(json.dumps({'utc':time.time(),'job':2812,'staged':True,'hash_validation':'worker validates before loading'}))
while True:
 s=subprocess.check_output(['systemctl','--user','show','language-pilot-resume-eval-2811-2812-20261014','-p','ActiveState'],text=True)
 if 'ActiveState=active' not in s and 'ActiveState=activating' not in s:break
 time.sleep(30)
used=subprocess.check_output(sr(2812)+['nvidia-smi','-i','0','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True)
assert int(used.strip())<1000
subprocess.run(sr(2812)+['/fsx/home/zhiyuan/miniconda3/envs/megatron-sft/bin/python',str(C/'worker.py'),str(D/'prior-A50.json'),'0'],check=True)
