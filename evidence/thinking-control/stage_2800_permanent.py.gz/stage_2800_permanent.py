import json,subprocess,fcntl,time
from pathlib import Path
C=Path(__file__).resolve().parent;R=C.parent;N=Path('/opt/dlami/nvme/zhiyuan/language-pilot-20261011/thinking-eval-20261014');label='prior-checkpoint-2800'
m=json.loads((R/'evaluation-notags-246-v1/weights'/(label+'.json')).read_text());item=json.loads((C/'idle-gpu-items'/(label+'.json')).read_text())
assert m['verified'] and m['repo']==item['repo'] and m['revision']==item['revision'];files=m['files']
lock=(C/'model-locks'/(label+'.lock')).open('a');fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
src=Path('/opt/dlami/nvme/zhiyuan/qwen-long-all42-20261012/checkpoint-2800');root=N/'temporary-models'/label;dst=root/'model'
def sr(j):return ['srun','--jobid='+str(j),'--overlap','-N1','-n1','-c1','--immediate=30']
def node(j,s):return subprocess.run(sr(j)+['python3','-c',s],stdin=subprocess.DEVNULL,check=True)
verify="import pathlib,hashlib,json;p=pathlib.Path(PATH);files=FILES\nfor x in files:\n f=p/x['file'];assert f.stat().st_size==x['bytes'];h=hashlib.sha256()\n with f.open('rb') as t:\n  while b:=t.read(8*1024**2):h.update(b)\n assert h.hexdigest()==x['sha256'],x['file']\nprint('VERIFIED',len(files),flush=True)"
node(2546,'PATH='+repr(str(src))+';FILES='+repr(files)+'\n'+verify)
node(2742,'from pathlib import Path;import shutil;p=Path('+repr(str(dst))+');p.mkdir(parents=True,exist_ok=True);assert shutil.disk_usage(p).free>'+str(sum(x['bytes'] for x in files)+80*2**30))
with (C/'stage-2800-permanent.log').open('a') as log:
 a=subprocess.Popen(sr(2546)+['tar','-C',str(src),'-cf','-']+[x['file'] for x in files],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=log)
 b=subprocess.Popen(sr(2742)+['tar','-C',str(dst),'-xf','-'],stdin=a.stdout,stdout=log,stderr=log);a.stdout.close();br=b.wait();ar=a.wait();assert ar==br==0
node(2742,'PATH='+repr(str(dst))+';FILES='+repr(files)+'\n'+verify)
receipt=dict(verified=True,repo=item['repo'],revision=item['revision'],files=files,source_job=2546,source_path=str(src),utc=time.time())
node(2742,'from pathlib import Path;import json;p=Path('+repr(str(root/'verified-local-copy.json'))+');p.write_text('+repr(json.dumps(receipt))+')')
(C/'prior2800-local-copy-ready.json').write_text(json.dumps(receipt));print('COPY_READY',flush=True)
