import json,hashlib,sys,time
from pathlib import Path
from jinja2.sandbox import ImmutableSandboxedEnvironment
R=Path('/fsx/home/zhiyuan/language-pilot-20261011');O=R/'evaluation-thinking-246-v1';OLD=R/'evaluation-expanded-200-v1';item=json.loads(Path(sys.argv[1]).read_text());label=item['label'];mode='thinking-sampled';out=O/mode/(label+'.jsonl');receipt=O/'status'/(label+'.reused200.json')
if receipt.exists():sys.exit(0)
source=OLD/mode/(label+'.jsonl');meta=source.with_suffix('.metadata.json')
if not source.exists() or not meta.exists():sys.exit(0)
m=json.loads(meta.read_text())
for k,v in {'model':label,'revision':item['revision'],'temperature':0.6,'top_p':0.95,'enable_thinking':True,'max_new_tokens':16384,'max_model_len':32768,'dtype':'bfloat16','seeds':[42],'stop_token_ids':[248046,248044]}.items():assert m[k]==v,(k,m.get(k),v)
oldp={x['id']:x for x in map(json.loads,(R/'eval-200-v2/prompts.jsonl').read_text().splitlines())};newp={x['id']:x for x in map(json.loads,(R/'eval-three-subsets-v1/prompts.jsonl').read_text().splitlines())}
for i,p in oldp.items():
 for k in ['messages','images','rubric','target_language']:assert p[k]==newp[i][k]
env=ImmutableSandboxedEnvironment(trim_blocks=True,lstrip_blocks=True);oldtemplate=env.from_string((OLD/'templates'/(label+'.jinja')).read_text());newtemplate=env.from_string((O/'templates'/(label+'.jinja')).read_text())
for p in oldp.values():
 args=dict(messages=p['messages'],add_generation_prompt=True,enable_thinking=True,pilot_mode=mode)
 assert oldtemplate.render(**args)==newtemplate.render(**args),'Rendered template differs'
byid={x['id']:x for x in map(json.loads,source.read_text().splitlines()) if x.get('status')=='ok'};assert set(byid)==set(oldp);out.parent.mkdir(exist_ok=True)
assert not out.exists(),'Never overwrite new results'
out.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in byid.values()))
S=O/'scores100';S.mkdir(exist_ok=True);oldscore=OLD/'scores100'/(mode+'-'+label+'.jsonl');scores={}
if oldscore.exists():
 for line in oldscore.read_text().splitlines():
  x=json.loads(line)
  if x.get('status')=='ok' and x['id'] in byid and x['candidate_sha256']==hashlib.sha256(json.dumps(byid[x['id']],sort_keys=True).encode()).hexdigest():scores[x['id']]=x
# Judge may already be reading seeded answers; only create score file if still absent.
scorepath=S/(mode+'-'+label+'.jsonl')
if scores:
 try:
  with scorepath.open('x') as f:f.write(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in scores.values()))
 except FileExistsError:pass
receipt.write_text(json.dumps({'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cases':200,'candidate_sha256':{i:hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest() for i,x in byid.items()},'config_and_all_rendered_prompts_equal':True,'utc':time.time()}))
print('REUSED_VERIFIED',label,200,flush=True)
