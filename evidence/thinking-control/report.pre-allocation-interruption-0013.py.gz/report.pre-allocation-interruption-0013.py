import json,statistics,time,html
from pathlib import Path
R=Path('/fsx/home/zhiyuan/language-pilot-20261011');O=R/'evaluation-thinking-246-v1';C=R/'thinking-eval-20261014';keys=['accuracy','language','logic','instruction','completeness'];P={x['id']:x for x in map(json.loads,(R/'eval-three-subsets-v1/prompts.jsonl').read_text().splitlines())};out=[]
def read(p):
 a={}
 if p.exists():
  for l in p.read_text().splitlines():
   try:x=json.loads(l)
   except json.JSONDecodeError:continue
   if x.get('status')=='ok':a[x['id']]=x
 return a
for item in json.loads((C/'queue.json').read_text())['items']:
 for mode in item['modes']:
  label=item['label'];a=read(O/'scores100'/(mode+'-'+label+'.jsonl'));r=read(O/mode/(label+'.jsonl'))
  for subset,n in [('diagnostic128',128),('benchmark72',72),('friend46',46)]:
   aa=[x for i,x in a.items() if P[i]['subset']==subset];rr=[x for i,x in r.items() if P[i]['subset']==subset];means={k:statistics.mean(x['assessment']['scores'][k] for x in aa) for k in keys} if aa else {}
   row={'model':label,'mode':mode,'subset':subset,'responses':len(rr),'graded':len(aa),'expected':n,'provisional':len(aa)!=n,'means':{k:round(v,2) for k,v in means.items()},'overall':round(statistics.mean(means.values()),2) if means else None,'missing_final':sum(not x.get('final_answer') for x in rr),'length_limited':sum(x.get('finish_reason')=='length' for x in rr)}
   objective=O/mode/(label+'.objective.json')
   if subset=='benchmark72' and objective.exists():row['objective']=json.loads(objective.read_text())['groups']
   out.append(row)
note='本轮只跑用户指定两组：T=0.6/top_p=0.95，T=1/top_p=1；均enable_thinking=true，生成前缀为开放<think>，每模型保存真实渲染审计。三subset分别汇总，T0.6前200题仅在配置和模型SHA核对一致时复用，保留溯源。BF16/context32768/output16384/seed42。五项直接百分制模型辅助评分，等权整体；未完成显示n/对应subset总题数。公开72题严格标准答案正确数独立于judge评分。严格匹配包含格式要求；解析失败单列，不能直接等同知识错误，模型辅助评分也不能替代标准答案正确率。'
note += 'Codex辅助复核（非人工标注，2026-10-13）：已确认prior-historical100在无标签T=0.6/top_p=0.95的ARC153题漏判：标准答案B（热能转化为化学能），模型答C，Judge准确性仍给100分。原评分与严格判错均保留，未覆盖分数。这说明Judge高分不能替代标准答案核验。复核证据见judge-gold-disagreement-audit-1906.json；该证据为当时快照，不代表全量复核完成。'
note += 'Thinking格式与上下文须分开判断：未闭合</think>本身不证明上下文用完，正常stop也可能直接给出实质答案；当前评分规则对未闭合输出的指令和完整性各设50分上限，需连同原始答案解读。真实上下文耗尽案例：prior-A50的thinking-sampled（T=0.6/top_p=0.95）朋友多轮EM2，首轮输出16384 tokens，第二轮输入16497、输出16271、总计32768；保留完整实际历史的第三轮friend-EM2-3遭HTTP400，当前该设置245/246成功，不标完整完成。HTTP错误体当时未保存，上下文诊断依据前两轮实际usage；原回答和错误记录保留，未截断历史或改变上下文。T=1另行排队补测，T=0.6处理方式待用户决定。证据：A50-dialogue-context-exhaustion-2106.json。'
note += '补充抽查（Codex辅助复核，非人工标注）：对照7901条已有公开题评分发现5条可抽取答案与标准答案不同、但准确性>=90的记录。除已知ARC153漏判外，其余包括先答对再改成矛盾答案，以及答对后续写另一道无关题。部分Judge已指出这些问题并扣格式分，但准确性、语言或逻辑仍给高分。因此高语义分不代表整段输出正确，严格答案与完整原文应同时查看。此为抽查快照，不是全量错误率；原评分未改。证据：judge-explicit-answer-disagreements-2159.json。'
note += '新增实证：Stage2 checkpoint-3700的Thinking T=0.6/top_p=0.95为245/246，friend-EM1前两轮分别输出16384和16278 tokens，均length；第三轮HTTP400明确报告输入至少32769超过32768。T=1/top_p=1同模型已246/246，EM1三轮分别输出82/83/29 tokens并正常stop。此案例区分真实上下文耗尽与仅缺think闭合；不能由单例推出T=1普遍更好。原始记录保留，未截断历史或改context，T0.6未标完整完成。证据stage23700-context-exhaustion-2242.json。'
note += '另一个上下文耗尽案例：旧checkpoint-2300的Thinking T=0.6/top_p=0.95为245/246，friend-EM1-3返回HTTP400，明确输入至少32769超过32768；同模型T=1/top_p=1为246/246。保留完整历史、原错误和临时权重，未改context；不据此推断T=1普遍更优。证据prior2300-context-exhaustion-2313.json。'
note += '新增上下文耗尽案例：旧checkpoint-100（prior-historical100）的Thinking T=0.6/top_p=0.95成功245/246，friend-EM2-3返回HTTP400明确输入至少32769超过32768；后续已核实T=1/top_p=1成功246/246，EM2三轮分别输出828/4337/1843 tokens且均stop；T=0.6仍245/246，因此整个模型不标全部完成，不能由此单例推出T=1普遍更好。保留完整历史和原始错误，不标完整完成。证据historical100-context-exhaustion-2339.json。'
(O/'summary.json').write_text(json.dumps({'utc':time.time(),'note':note,'results':out},ensure_ascii=False,indent=2))
parts=['<!doctype html><meta charset=utf-8><title>开放think标签两组评测</title><style>body{font:14px system-ui;margin:24px}table{border-collapse:collapse}td,th{padding:7px;border:1px solid #ccc}</style><h1>开放think标签：两个采样设置，三个subset</h1><p>'+html.escape(note)+'</p>']
for subset in ['diagnostic128','benchmark72','friend46']:
 parts.append('<h2>'+subset+'</h2><table><tr>'+''.join('<th>'+x+'</th>' for x in ['模型','设置','回答','评分','准确性','语言','逻辑','指令','完整性','整体','缺final','length','标准答案正确/72','标准答案解析失败'])+'</tr>')
 for r in out:
  if r['subset']!=subset:continue
  vals=[r['model'],r['mode'],str(r['responses'])+'/'+str(r['expected']),str(r['graded'])+'/'+str(r['expected'])+(' 临时' if r['provisional'] else '')]+[r['means'].get(k,'—') for k in keys]+[r['overall'] if r['overall'] is not None else '—',r['missing_final'],r['length_limited'],r.get('objective',{}).get('all72',{}).get('correct','—'),r.get('objective',{}).get('all72',{}).get('parse_failures','—')]
  parts.append('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in vals)+'</tr>')
 parts.append('</table>')
(O/'report.html').write_text(''.join(parts))
