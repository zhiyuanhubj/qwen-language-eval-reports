import subprocess,time,json
from pathlib import Path
C=Path('/fsx/home/zhiyuan/language-pilot-20261011/thinking-eval-20261014')
for attempt in range(80):
 p=subprocess.run(['srun','--jobid=2812','--overlap','-N1','-n1','-c1','--immediate=10','curl','-fsS','--max-time','5','http://127.0.0.1:30241/health'],capture_output=True)
 if p.returncode==0:
  subprocess.run(['systemctl','--user','restart','language-pilot-thinking-judge-20261014','language-pilot-notags-judge-20261014'],check=True)
  (C/'long-judge-activated.json').write_text(json.dumps({'utc':time.time(),'health_verified':True,'judge_max_context':131072,'candidate_max_context_unchanged':32768,'endpoint':'http://10.1.30.86:30241','fallback_only':True}))
  print('ACTIVATED_LONG_CONTEXT_FALLBACK',flush=True);break
 state=subprocess.check_output(['systemctl','--user','show','qwen-eval-long-judge-20261014','-p','ActiveState'],text=True)
 if 'ActiveState=failed' in state:raise RuntimeError('Long-context judge startup failed; original scoring continues')
 time.sleep(30)
else:raise RuntimeError('Long-context judge health timeout; original scoring continues')
