import sys,os,json,hashlib,subprocess,time,shutil,traceback,fcntl
from pathlib import Path
from huggingface_hub import HfApi
import requests
C=Path('/fsx/home/zhiyuan/language-pilot-20261011/thinking-eval-20261014');R=C.parent;N=Path('/opt/dlami/nvme/zhiyuan/language-pilot-20261011/thinking-eval-20261014');OUT=R/'evaluation-thinking-246-v1';PY=sys.executable
item=json.loads(Path(sys.argv[1]).read_text());gpu=int(sys.argv[2]);label=item['label'];root=N/'temporary-models'/label;model=root/'model';port=19600+gpu;container='pilot-thinking-'+label
OUT.mkdir(exist_ok=True);(OUT/'status').mkdir(exist_ok=True);(OUT/'weights').mkdir(exist_ok=True)
def atomic(p,x):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2));t.replace(p)
def state(s,**kw):atomic(OUT/'status'/(label+'.json'),dict(state=s,gpu=gpu,utc=time.time(),**kw));print(label,s,flush=True)
def sha(p,kind='sha256'):
 h=hashlib.new(kind)
 if kind=='sha1':h.update(('blob '+str(p.stat().st_size)+'\0').encode())
 with p.open('rb') as f:
  while b:=f.read(16*1024**2):h.update(b)
 return h.hexdigest()
def complete(mode):
 p=OUT/mode/(label+'.jsonl')
 if not p.exists():return False
 rows=[json.loads(l) for l in p.read_text().splitlines()];ids={x['id'] for x in rows if x.get('status')=='ok'};expected={x['id'] for x in map(json.loads,(R/'eval-three-subsets-v1/prompts.jsonl').read_text().splitlines())}
 return ids==expected
(C/'model-locks').mkdir(exist_ok=True)
model_lock=(C/'model-locks'/(label+'.lock')).open('a')
try:
 fcntl.flock(model_lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:
 print(label,'SKIP_MODEL_ALREADY_RUNNING',flush=True);sys.exit(0)
try:
 if all(complete(m) for m in item['modes']):state('already_completed');sys.exit(0)
 assert shutil.disk_usage(N).free>120*2**30,'NVMe reserve'
 root.mkdir(parents=True,exist_ok=True);env=dict(os.environ,HF_HUB_DISABLE_PROGRESS_BARS='1',HF_HUB_DISABLE_XET='1',HF_XET_CACHE=str(root/'xet-cache'))
 if (root/'verified-local-copy.json').exists():
  state('verifying_local_copy')
  receipt=json.loads((root/'verified-local-copy.json').read_text())
  baseline=json.loads((R/'evaluation-notags-246-v1/weights'/(label+'.json')).read_text())
  assert receipt['verified'] and baseline['verified']
  assert receipt['repo']==baseline['repo']==item['repo'] and receipt['revision']==baseline['revision']==item['revision']
  assert receipt['files']==baseline['files'];files=receipt['files']
  for x in files:
   f=model/x['file'];assert f.is_file() and f.stat().st_size==x['bytes'] and sha(f)==x['sha256'],x['file']
 elif item.get('repo') and (R/'evaluation-notags-246-v1/weights'/(label+'.json')).exists():
  state('downloading_verified_manifest',revision=item['revision'])
  baseline=json.loads((R/'evaluation-notags-246-v1/weights'/(label+'.json')).read_text())
  assert baseline['verified'] is True
  assert baseline['repo']==item['repo'] and baseline['revision']==item['revision']
  files=baseline['files'];assert files and any(x['file'].endswith('.safetensors') for x in files)
  assert all(Path(x['file']).name==x['file'] and x['file'] not in ('.','..') for x in files)
  subprocess.run([str(Path(PY).parent/'hf'),'download',item['repo'],*[x['file'] for x in files],'--revision',item['revision'],'--local-dir',str(model),'--max-workers','4'],env=env,stdin=subprocess.DEVNULL,check=True)
  state('verifying_weights')
  for x in files:
   f=model/x['file'];assert f.is_file() and f.stat().st_size==x['bytes'] and sha(f)==x['sha256'],x['file']
 elif item.get('repo'):
  state('downloading',revision=item['revision'])
  for attempt in range(3):
   try:
    info=HfApi().model_info(item['repo'],revision=item['revision'],files_metadata=True);break
   except Exception as hub_error:
    response=getattr(hub_error,'response',None)
    if getattr(response,'status_code',None) not in (429,500,502,503,504) or attempt==2:raise
    print(label,'HF_METADATA_RETRY',attempt+1,flush=True);time.sleep(5*(attempt+1))
  assert info.sha==item['revision']
  selected=[x for x in info.siblings if x.rfilename.endswith(('.json','.jinja','.safetensors','.model','.txt')) and '/' not in x.rfilename]
  assert any(x.rfilename.endswith('.safetensors') for x in selected)
  subprocess.run([str(Path(PY).parent/'hf'),'download',item['repo'],*[x.rfilename for x in selected],'--revision',item['revision'],'--local-dir',str(model),'--max-workers','4'],env=env,stdin=subprocess.DEVNULL,check=True)
  state('verifying_weights');files=[]
  for x in selected:
   f=model/x.rfilename;assert f.is_file() and f.stat().st_size==x.size,x.rfilename
   digest=sha(f)
   if x.lfs:assert digest==x.lfs.sha256,x.rfilename
   else:assert sha(f,'sha1')==x.blob_id,x.rfilename
   files.append(dict(file=x.rfilename,bytes=f.stat().st_size,sha256=digest))
 else:
  state('verifying_staged_weights');files=item['files']
  for x in files:
   f=model/x['file'];assert f.stat().st_size==x['bytes'] and sha(f)==x['sha256'],str(f)
 atomic(OUT/'weights'/(label+'.json'),dict(verified=True,repo=item.get('repo'),revision=item['revision'],files=files,temporary_path=str(model)))
 subprocess.run([PY,str(C/'prepare_templates.py'),str(model),str(OUT/'templates'),label],stdin=subprocess.DEVNULL,check=True)
 subprocess.run([PY,str(C/'reuse_verified.py'),str(Path(sys.argv[1]))],stdin=subprocess.DEVNULL,check=True)
 state('loading')
 with (OUT/(label+'.server.log')).open('a') as log:
  p=subprocess.Popen(['docker','run','--rm','--name',container,'--gpus','device='+str(gpu),'--network','host','--ipc','host','-v','/fsx:/fsx:ro','-v',str(N)+':'+str(N)+':ro','--entrypoint','vllm','vllm/vllm-openai:zhiyuan-v41-7d0b4e57a','serve',str(model),'--served-model-name',label,'--chat-template',str(OUT/'templates'/(label+'.jinja')),'--host','127.0.0.1','--port',str(port),'--dtype','bfloat16','--max-model-len','32768','--max-num-seqs','16','--gpu-memory-utilization','0.85','--generation-config','vllm','--enforce-eager'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  for _ in range(240):
   if p.poll() is not None:raise RuntimeError('model server exited '+str(p.returncode))
   try:
    if requests.get('http://127.0.0.1:'+str(port)+'/health',timeout=3).status_code==200:break
   except requests.RequestException:pass
   time.sleep(5)
  else:raise RuntimeError('model server health timeout')
  for mode in item['modes']:
   if complete(mode):continue
   try:
    (OUT/mode).mkdir(exist_ok=True)
    for smoke in [True,False]:
     state('smoke' if smoke else 'evaluating',mode=mode)
     output=OUT/mode/(label+('.smoke' if smoke else '')+'.jsonl')
     cmd=[PY,str(C/'run_eval.py'),'--suite',str(R/'eval-three-subsets-v1'),'--output',str(output),'--model',label,'--revision',item['revision'],'--base-url','http://127.0.0.1:'+str(port)+'/v1','--authorization',str(C/'authorization.json'),'--workers','8','--mode',mode]
     if smoke:cmd.append('--smoke')
     subprocess.run(cmd,stdin=subprocess.DEVNULL,check=True)
     rows=[json.loads(l) for l in output.read_text().splitlines()];assert len({x['id'] for x in rows if x['status']=='ok'})==(4 if smoke else 246)
    subprocess.run([PY,str(C/'score_benchmark_exact.py'),'--suite',str(R/'eval-three-subsets-v1'),'--responses',str(output),'--output',str(OUT/mode/(label+'.objective.json'))],stdin=subprocess.DEVNULL,check=True)
   except Exception as mode_error:
    atomic(OUT/'status'/(label+'.'+mode+'.failed.json'),dict(mode=mode,error=repr(mode_error),utc=time.time(),state='mode_failed',temporary_weights_retained=True))
    print(label,mode,'MODE_FAILED',repr(mode_error),flush=True);traceback.print_exc()
    continue
  subprocess.run(['docker','stop',container],stdin=subprocess.DEVNULL,check=True);assert p.wait(timeout=60) in (0,143)
 assert all(complete(m) for m in item['modes'])
 receipts={m:dict(cases=246,sha256=sha(OUT/m/(label+'.jsonl'))) for m in item['modes']}
 atomic(OUT/'status'/(label+'.completed.json'),dict(completed=True,revision=item['revision'],modes=receipts,utc=time.time()))
 # User explicitly authorized removing only these freshly staged/downloaded temporary weights after all modes complete.
 assert root.parent==N/'temporary-models' and root.resolve()==root and not root.is_symlink()
 shutil.rmtree(root)
 atomic(OUT/'status'/(label+'.temporary-cleaned.json'),dict(user_authorized=True,path=str(root),results=receipts,utc=time.time()))
 state('completed',modes=item['modes'])
except Exception as e:
 state('failed',error=repr(e));traceback.print_exc()
 subprocess.run(['docker','stop',container],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 raise
