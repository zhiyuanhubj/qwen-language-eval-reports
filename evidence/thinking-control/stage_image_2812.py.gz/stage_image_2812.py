import subprocess
image='vllm/vllm-openai:zhiyuan-v41-7d0b4e57a'
def sr(j):return ['srun','--jobid='+str(j),'--overlap','-N1','-n1','-c2','--immediate=30']
a=subprocess.Popen(sr(2811)+['docker','save',image],stdout=subprocess.PIPE)
b=subprocess.Popen(sr(2812)+['docker','load'],stdin=a.stdout)
a.stdout.close()
br=b.wait();ar=a.wait();assert ar==br==0,(ar,br)
x=[]
for j in [2811,2812]:x.append(subprocess.check_output(sr(j)+['docker','image','inspect',image,'--format','{{.Id}}'],text=True).strip())
assert x[0]==x[1],x
print('VERIFIED_IMAGE',x[0],flush=True)
