from pathlib import Path
import subprocess,time,json
R=Path('/fsx/home/zhiyuan/language-pilot-20261011');C=R/'thinking-eval-20261014'
while subprocess.run(['systemctl','--user','is-active','--quiet','qwen-eval-evidence-publish-20261014']).returncode==0:time.sleep(10)
subprocess.run(['python3',str(C/'publish_control_evidence.py')],check=True)
subprocess.run(['systemd-run','--user','--unit=qwen-eval-github-sync-20261014','--property=StandardOutput=append:'+str(C/'github-report-sync.log'),'--property=StandardError=append:'+str(C/'github-report-sync.log'),'python3',str(C/'github_report_sync.py')],check=True)
