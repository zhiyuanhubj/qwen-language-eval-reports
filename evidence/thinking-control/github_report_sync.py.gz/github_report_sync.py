import json,shutil,subprocess,time,datetime
from pathlib import Path
R=Path('/fsx/home/zhiyuan/language-pilot-20261011');D=Path('/fsx/home/zhiyuan/qwen-language-eval-reports')
def sync():
 status={}
 for kind in ['thinking','notags']:
  source=R/f'evaluation-{kind}-246-v1';dest=D/kind
  raw=(source/'summary.json').read_bytes();data=json.loads(raw)
  (dest/'summary.json').write_bytes(raw);shutil.copy2(source/'report.html',dest/'report.html')
  status[kind]={'updated_utc':datetime.datetime.fromtimestamp(data['utc'],datetime.timezone.utc).isoformat(),**{k:sum(x[k] for x in data['results']) for k in ['responses','graded','expected']}}
 (D/'status.json').write_text(json.dumps(status,indent=2)+'\n')
 subprocess.run(['git','-C',str(D),'add','thinking','notags','status.json'],check=True)
 if subprocess.run(['git','-C',str(D),'diff','--cached','--quiet']).returncode:
  subprocess.run(['git','-C',str(D),'commit','-m','Update evaluation report snapshot and completion counts'],check=True)
 subprocess.run(['git','-C',str(D),'push','origin','main'],check=True)
 print(json.dumps(status),flush=True)
 return all(x['graded']==x['responses'] for x in status.values())
end=time.time()+24*3600
while time.time()<end:
 try:
  if sync():break
 except Exception as exc:print('SYNC_RETRY',repr(exc),flush=True)
 time.sleep(900)
