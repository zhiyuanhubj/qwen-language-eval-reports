from pathlib import Path
import gzip,hashlib,json,subprocess,time,shutil,re
R=Path('/fsx/home/zhiyuan/language-pilot-20261011');D=Path('/fsx/home/zhiyuan/qwen-language-eval-reports')
files=[];secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|hf_[A-Za-z0-9]{30,}|sk-proj-[A-Za-z0-9_-]{30,})')
for kind,source in [('thinking',R/'evaluation-thinking-246-v1'),('notags',R/'evaluation-notags-246-v1'),('questions',R/'eval-three-subsets-v1')]:
 for f in sorted(source.rglob('*')):
  if not f.is_file() or f.is_symlink() or 'weights' in f.relative_to(source).parts:continue
  if f.suffix not in ['.json','.jsonl','.log','.html','.txt','.yaml','.py','.jinja']:continue
  if kind!='questions' and f.name in ['report.html','summary.json']:continue
  rel=f.relative_to(source);out=D/'evidence'/kind/(str(rel)+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
  h=hashlib.sha256();size=0;redactions=0
  with f.open('rb') as src,out.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as dst:
   for line in src:
    line,n=secret.subn(b'[REDACTED_CREDENTIAL]',line);redactions+=n;h.update(line);size+=len(line);dst.write(line)
  assert out.stat().st_size<95*1024**2,str(out)
  files.append({'source':str(f.relative_to(R)),'artifact':str(out.relative_to(D)),'uncompressed_bytes':size,'sha256_uncompressed':h.hexdigest(),'gzip_bytes':out.stat().st_size,'sha256_gzip':hashlib.sha256(out.read_bytes()).hexdigest(),'credential_redactions':redactions})
 print('EXPORTED',kind,len(files),flush=True)
for kind in ['thinking','notags']:
 source=R/f'evaluation-{kind}-246-v1'
 for name in ['report.html','summary.json']:shutil.copy2(source/name,D/kind/name)
manifest={'snapshot_utc':time.time(),'complete_run':False,'description':'All existing files with evaluation questions, raw responses (including reasoning), scores, errors, prompt templates and run logs from both report source directories. Weights excluded. Scores are still being added; snapshot is not a claim all tests succeeded. Original newlines and failed records preserved. Files compressed individually with gzip.','files':files}
(D/'evidence/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(D/'evidence/README.md').write_text('# Evaluation evidence snapshot\n\nQuestions, complete raw model output, per-question scores, errors, prompt templates, and run logs are stored by source path. Each `.gz` file can be decompressed with `gzip -dk FILE.gz`. The manifest lists sizes and SHA-256 checksums.\n\nThis is all evidence present at the snapshot time, not a claim all evaluations completed. Model weights are excluded. The questions folder includes benchmark answers; response files retain model reasoning and final answers. Scoring may still be in progress.\n')
p=D/'README.md';s=p.read_text();link='\n\n[Downloadable questions, answers, scores and logs](evidence/README.md) · [File manifest and checksums](evidence/manifest.json)\n';p.write_text(s+link if 'evidence/README.md' not in s else s)
subprocess.run(['git','-C',str(D),'add','evidence','README.md','thinking','notags'],check=True)
subprocess.run(['git','-C',str(D),'commit','-m','Publish complete available evaluation evidence snapshot, questions, responses and logs'],check=True)
subprocess.run(['git','-C',str(D),'push','origin','main'],check=True)
print('PUBLISHED',len(files),sum(x['uncompressed_bytes'] for x in files),sum(x['gzip_bytes'] for x in files),flush=True)
