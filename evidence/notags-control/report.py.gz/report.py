import json,statistics,time,html
from pathlib import Path
R=Path('/fsx/home/zhiyuan/language-pilot-20261011');O=R/'evaluation-notags-246-v1';C=R/'notags-eval-20261014';keys=['accuracy','language','logic','instruction','completeness'];P={x['id']:x for x in map(json.loads,(R/'eval-three-subsets-v1/prompts.jsonl').read_text().splitlines())};out=[]
def read(p):
 a={}
 if p.exists():
  for l in p.read_text().split('\n'):
   if not l:continue
   try:x=json.loads(l)
   except json.JSONDecodeError:continue
   if x.get('status')=='ok':a[x['id']]=x
 return a
for item in json.loads((C/'queue.json').read_text())['items']:
 for mode in item['modes']:
  label=item['label'];a=read(O/'scores100'/(mode+'-'+label+'.jsonl'));r=read(O/mode/(label+'.jsonl'))
  for subset,n in [('diagnostic128',128),('benchmark72',72),('friend46',46)]:
   aa=[x for i,x in a.items() if P[i]['subset']==subset];rr=[x for i,x in r.items() if P[i]['subset']==subset];means={k:statistics.mean(x['assessment']['scores'][k] for x in aa) for k in keys} if aa else {}
   row={'model':label,'mode':mode,'subset':subset,'responses':len(rr),'graded':len(aa),'expected':n,'provisional':len(aa)!=n,'means':{k:round(v,2) for k,v in means.items()},'overall':round(statistics.mean(means.values()),2) if means else None,'missing_final':sum(not x.get('final_answer') for x in rr),'length_limited':sum(x.get('finish_reason')=='length' for x in rr)}
   objective=O/mode/(label+'.objective.json')
   if subset=='benchmark72' and objective.exists():row['objective']=json.loads(objective.read_text())['groups']
   out.append(row)
note='本轮只跑用户指定两组：T=0.6/top_p=0.95，T=1/top_p=1；均enable_thinking=false，生成前缀没有<think>或</think>，每模型保存真实渲染审计。三subset分别汇总，不混旧空think块结果。BF16/context32768/output16384/seed42。五项直接百分制模型辅助评分，等权整体；未完成显示n/对应subset总题数。公开72题严格标准答案正确数独立于judge评分。严格匹配包含格式要求；解析失败单列，不能直接等同知识错误，模型辅助评分也不能替代标准答案正确率。'
note += 'Codex辅助复核（非人工标注，2026-10-13）：已确认prior-historical100在无标签T=0.6/top_p=0.95的ARC153题漏判：标准答案B（热能转化为化学能），模型答C，Judge准确性仍给100分。原评分与严格判错均保留，未覆盖分数。这说明Judge高分不能替代标准答案核验。复核证据见judge-gold-disagreement-audit-1906.json；该证据为当时快照，不代表全量复核完成。'
note += '补充抽查（Codex辅助复核，非人工标注）：对照7901条已有公开题评分发现5条可抽取答案与标准答案不同、但准确性>=90的记录。除已知ARC153漏判外，其余包括先答对再改成矛盾答案，以及答对后续写另一道无关题。部分Judge已指出这些问题并扣格式分，但准确性、语言或逻辑仍给高分。因此高语义分不代表整段输出正确，严格答案与完整原文应同时查看。此为抽查快照，不是全量错误率；原评分未改。证据：judge-explicit-answer-disagreements-2159.json。'
note += '扩展抽查（2026-10-14）：对12509条可配对公开题评分筛出7条明确提取答案不同而准确性>=90的记录，比前次新增2条。Codex辅助复核（非人工标注）发现：旧checkpoint2000的Thinking T0.6在ARC350先正确答D，随后自创细菌题并以B结束；旧checkpoint2500的Thinking T1在GSM153先写ANSWER:18、ANSWER:36，末尾正文改为48却未给ANSWER:48，并含错误代数推导。两例均正常stop且未闭合think；不能直接算作两例新知识错误。严格格式判分和Judge语义高分须连同全文解读，原评分未改。证据judge-discrepancy-screen-0039.json。'
(O/'summary.json').write_text(json.dumps({'utc':time.time(),'note':note,'results':out},ensure_ascii=False,indent=2))
from report_layout import render
(O/'report.html').write_text(render({'utc':time.time(),'note':note,'results':out},'无Thinking、无标签 · 两组采样评测'))
