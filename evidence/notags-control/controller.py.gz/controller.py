import os,json,time,subprocess,concurrent.futures,queue,threading,hashlib
from pathlib import Path
C=Path(__file__).resolve().parent;R=C.parent;OUT=R/'evaluation-notags-246-v1';N=Path('/opt/dlami/nvme/zhiyuan/language-pilot-20261011/notags-eval-20261014');E='/fsx/home/zhiyuan/miniconda3/envs/megatron-sft/bin/python';Q=json.loads((C/'queue.json').read_text());jobs=queue.Queue();lock=threading.Lock()
OUT.mkdir(exist_ok=True);(C/'items').mkdir(exist_ok=True)
def sr(j,c=2):return ['srun','--jobid='+str(j),'--overlap','-N1','-n1','-c'+str(c),'--immediate=30']
def node(j,code):return subprocess.run(sr(j)+[E,'-c',code],stdin=subprocess.DEVNULL,capture_output=True,text=True,check=True).stdout
while not (C/'image-ready.json').exists() or not (C/'suite-ready.json').exists():time.sleep(5)
# Original87 finished; A150/A200 addon uses GPUs0/1 only. Reserve2..7.
assert (R/'evaluation-expanded-200-v1/initial87-complete.json').exists()
# Exclusive designated eval node; refuse launch if another GPU workload has appeared.
used=node(2742,"import subprocess;print(subprocess.check_output(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],text=True))")
assert max(int(x) for x in used.split()[2:])<1000,used
node(2742,'from pathlib import Path;Path('+repr(str(N))+').mkdir(parents=True,exist_ok=True)')
for item in Q['items']:
 if not (OUT/'status'/(item['label']+'.completed.json')).exists():jobs.put(item)
def stage_local(item):
 label=item['label'];target=N/'temporary-models'/label/'model';node(2742,'from pathlib import Path;import shutil;p=Path('+repr(str(target))+');p.mkdir(parents=True,exist_ok=True);assert shutil.disk_usage(p).free>120*2**30')
 if item['source_job']==2742:
  node(2742,'import shutil;shutil.copytree('+repr(item['source_path'])+','+repr(str(target))+',dirs_exist_ok=True)')
 else:
  with lock,(OUT/(label+'.transfer.log')).open('a') as log:
   a=subprocess.Popen(sr(item['source_job'])+['tar','-C',item['source_path'],'-cf','-']+[x['file'] for x in item['files']],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=log)
   b=subprocess.Popen(sr(2742)+['tar','-C',str(target),'-xf','-'],stdin=a.stdout,stdout=log,stderr=log);a.stdout.close();br=b.wait();ar=a.wait();assert ar==br==0

def worker(g):
 while True:
  try:item=jobs.get_nowait()
  except queue.Empty:return
  try:
   if not item.get('repo'):stage_local(item)
   p=C/'items'/(item['label']+'.json');p.write_text(json.dumps(item))
   with (OUT/(item['label']+'.client.log')).open('a') as log:
    ret=subprocess.run(sr(2742,8)+[E,str(C/'worker.py'),str(p),str(g)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
   if ret.returncode:print('FAILED',item['label'],ret.returncode,flush=True)
  except Exception as e:print('FAILED',item['label'],repr(e),flush=True)
  finally:jobs.task_done()
with concurrent.futures.ThreadPoolExecutor(6) as pool:list(pool.map(worker,range(2,8)))
missing=[x['label'] for x in Q['items'] if not (OUT/'status'/(x['label']+'.completed.json')).exists()]
(C/'controller-finished.json').write_text(json.dumps({'missing':missing,'utc':time.time()}))
if not missing:(OUT/'complete.json').write_text(json.dumps({'models':len(Q['items']),'utc':time.time()}))
